import mongoose from 'mongoose';

const matchSchema = new mongoose.Schema({  
  homeTeam: { type: String },
  awayTeam: { type: String },
  bets: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    betType: { type: String, enum: ['home', 'draw', 'away'] },
    amount: Number,
  }],
  status: { type: String, enum: ['active','cancelled', 'completed'], default: 'active' },
}, {timestamps: true});
 

const Match = mongoose.model('Match', matchSchema);

export default Match;
