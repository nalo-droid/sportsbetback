import mongoose from 'mongoose';

const betSchema = new mongoose.Schema({
  matchId: { type: String },
  betId: { type: String },
  homeTeam: { type: String },
  awayTeam: { type: String },
  bets: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    betType: { type: String, enum: ['home', 'draw', 'away'] },
    amount: Number,
  }],
  status: { type: String, enum: ['pending','active', 'completed'], default: 'pending' },
}, {timestamps: true});

betSchema.pre('save', function(next) {
  if (!this.betId) {
    this.betId = Math.floor(10000 + Math.random() * 90000).toString();
  }
  next();
});

const Bet = mongoose.model('Bet', betSchema);

export default Bet;
