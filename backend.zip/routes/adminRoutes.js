import express from 'express';
import Bet from '../models/Bet.js';
import User from '../models/User.js';
import Transaction from '../models/Transaction.js';

const router = express.Router();

router.get('/bets', async (req, res) => {
    try {
        const bets = await Bet.find({ status: { $ne: 'completed' } }).sort({ createdAt: -1 }).populate('bets.userId', 'username');
        return res.status(200).json(bets);
    } catch (error) {
        console.error('Error fetching bets:', error);
        return res.status(500).json({ error: 'An error occurred while fetching bets.' });
    }
});

router.post('/bet/credit-winner', async (req, res) => {
    const { betId, userId } = req.body;
    console.log('betId:', betId);
    console.log('userId:', userId);
    try {
        const bet = await Bet.findById( betId ).populate('bets.userId', 'username');
        const user = await User.findById(userId);
        if (!bet || !user) {
            return res.status(404).json({ error: 'Bet or user not found' });
        }

        if (bet.status === 'completed') {
            return res.status(404).json({ error: 'Already paidout' });
        }
        const userBet = bet.bets.find(b => b.userId._id.toString() === userId);
        const amount = userBet ? userBet.amount : null;
        // Calculate creditAmount and deduct 20%
        const creditAmount = amount * bet.bets.length;
        const deductedAmount = creditAmount * 0.2;
        const finalCreditAmount = creditAmount - deductedAmount;

 
        user.balance += finalCreditAmount;
        await user.save();
    
        // Create a transaction record
        const transaction = new Transaction({
          userId,
          betId: bet._id,
          amount,
          type: 'credit',
          status: 'completed'
        });
        await transaction.save();

        bet.status = 'completed';
        bet.save()
    

        return res.status(200).json({ bet, user, finalCreditAmount });
    } catch (error) {
        console.error('Error fetching bet or user details:', error);
        return res.status(500).json({ error: 'An error occurred while fetching bet or user details.' });
    }
});

export default router;