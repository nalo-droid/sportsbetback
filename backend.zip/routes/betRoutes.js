import express from 'express'; 
import Bet from '../models/Bet.js';
import User from '../models/User.js';
import Transaction from '../models/Transaction.js';

const router = express.Router();

router.get('/bets', async (req, res) => {
  try {
      const bets = await Bet.find({ status: { $ne: 'completed' } }).sort({ createdAt: -1 }).populate('bets.userId', 'username');
      return res.status(200).json(bets);
  } catch (error) {
      console.error('Error fetching bets:', error);
      return res.status(500).json({ error: 'An error occurred while fetching bets.' });
  }
});
 

router.post('/create', async (req, res) => {
  const { matchId, userId, betType, amount, homeTeam, awayTeam } = req.body;

  if (!matchId || !userId || !betType || !amount || !homeTeam || !awayTeam) {
    return res.status(400).json({ error: 'All fields are required: matchId, userId, betType, amount, homeTeam, awayTeam' });
  }

  try {
    // Fetch the existing bet for the match
    let bet = await Bet.findOne({ matchId });

    if (!bet) {
      // If no bet exists for the match, create a new one
      bet = new Bet({ matchId, homeTeam, awayTeam, bets: [] });
    }

    // Check if the user has already placed a bet on this match
    const existingUserBet = bet.bets.find(b => b.userId.toString() === userId);
    if (existingUserBet) {
      return res.status(400).json({ error: 'You have already placed a bet on this match.' });
    }

    // Check if the bet type is already taken
    const existingBetType = bet.bets.find(b => b.betType === betType);
    if (existingBetType) {
      return res.status(400).json({ error: `Bet type "${betType}" is already taken.` });
    }

    // Ensure only three users can bet
    if (bet.bets.length >= 3) {
      return res.status(400).json({ error: 'This match already has the maximum number of bets (3).' });
    }

    // Find the user and deduct the amount from their balance
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }
    if (user.balance < amount) {
      return res.status(400).json({ error: 'Insufficient balance.' });
    }
    user.balance -= amount;
    await user.save();

    // Create a transaction record
    const transaction = new Transaction({
      userId,
      betId: bet._id,
      amount,
      type: 'debit',
      status: 'completed'
    });
    await transaction.save();

    // Add the user's bet
    bet.bets.push({
      userId,
      betType,
      amount, 
    });

    // Save the updated bet document
    await bet.save();

    return res.status(201).json({ message: 'Bet placed successfully.', bet });
  } catch (error) {
    console.error('Error placing bet:', error);
    return res.status(500).json({ error: 'An error occurred while placing the bet.' });
  }
});


router.put('/accept/:matchId', async (req, res) => {
  const { matchId } = req.params;
  const { userId, betType, amount } = req.body;

  if (!userId || !betType || !amount) {
    return res.status(400).json({ error: 'All fields are required: userId, betType, amount' });
  }

  try {
    // Fetch the existing bet document for the match
    const bet = await Bet.findOne({ matchId });

    if (!bet) {
      return res.status(404).json({ error: 'No bets found for this match. Please create a new bet first.' });
    }

    // Check if the user has already placed a bet on this match
    const existingUserBet = bet.bets.find(b => b.userId.toString() === userId);
    if (existingUserBet) {
      return res.status(400).json({ error: 'You have already placed a bet on this match.' });
    }

    // Check if the bet type is already taken
    const existingBetType = bet.bets.find(b => b.betType === betType);
    if (existingBetType) {
      return res.status(400).json({ error: `Bet type "${betType}" is already taken.` });
    }

    // Ensure only three users can bet
    if (bet.bets.length >= 3) {
      return res.status(400).json({ error: 'This match already has the maximum number of bets (3).' });
    }

    // Find the user and deduct the amount from their balance
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }
    if (user.balance < amount) {
      return res.status(400).json({ error: 'Insufficient balance.' });
    }
    user.balance -= amount;
    await user.save();

    // Create a transaction record
    const transaction = new Transaction({
      userId,
      betId: bet._id,
      amount,
      type: 'debit',
      status: 'completed'
    });
    await transaction.save();

    bet.status = "active";
    // Add the user's bet
    bet.bets.push({
      userId,
      betType,
      amount, 
    });

    // Save the updated bet document
    await bet.save();

    return res.status(200).json({ message: 'Bet placed successfully.', bet });
  } catch (error) {
    console.error('Error updating bet:', error);
    return res.status(500).json({ error: 'An error occurred while placing the bet.' });
  }
});
router.delete('/delete/:matchId', async (req, res) => {
  const { matchId } = req.params;

  try {
    const bet = await Bet.findOneAndDelete({ matchId });

    if (!bet) {
      return res.status(404).json({ error: 'No bets found for this match.' });
    }

    return res.status(200).json({ message: 'Bet deleted successfully.' });
  } catch (error) {
    console.error('Error deleting bet:', error);
    return res.status(500).json({ error: 'An error occurred while deleting the bet.' });
  }
});

export default router;


