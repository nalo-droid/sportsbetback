import express from 'express';
import fetch from 'node-fetch';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const response = await fetch('https://api.football-data.org/v4/matches', {
      headers: { 'X-Auth-Token': process.env.FOOTBALLAPI }
    });
    const data = await response.json();
    res.json(data.matches);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const response = await fetch(`https://api.football-data.org/v4/matches/${id}`, {
      headers: { 'X-Auth-Token': process.env.FOOTBALLAPI }
    });
    const data = await response.json();
    res.json(data.match);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
