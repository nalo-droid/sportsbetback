import express from 'express';  
import Match from '../models/Match.js'; 
import User from '../models/User.js';
import Transaction from '../models/Transaction.js';

const router = express.Router();


router.get('/match-bettors/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const match = await Match.findById(id)
      .populate({
        path: 'bets.userId',
        select: 'username balance' 
      });
    
    if (!match) {
      return res.status(404).json({ message: 'Match not found' });
    }

    const bettors = match.bets.map(bet => ({
      user: bet.userId,
      betType: bet.betType
    }));

    res.json(bettors);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});


router.post('/create-match',  async (req, res) => {
    try {
      const { homeTeam, awayTeam, amount } = req.body;
  
      if (!homeTeam || !awayTeam || !amount) {
        return res.status(400).json({ message: 'Please provide both home and away teams' });
      }
  
      const bet = await Match.create({
        homeTeam,
        awayTeam, 
        amount,
        bets: []  
      });
  
      res.status(201).json(bet);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });



router.post('/update-match-score', async (req, res) => {
  try {
    const { matchId, betType, homeScore, awayScore } = req.body;
    
    // Determine winner based on scores
    let winnerTeam;
    if (parseInt(homeScore) > parseInt(awayScore)) {
      winnerTeam = 'home';
    } else if (parseInt(homeScore) < parseInt(awayScore)) {
      winnerTeam = 'away';
    } else {
      winnerTeam = 'draw';
    }

    const match = await Match.findById(matchId).populate('bets.userId');

    // Get winning players
    const winningPlayers = winnerTeam === 'draw' 
      ? match.bets 
      : match.bets.filter(bet => bet.betType === winnerTeam);

    console.log('Match updated:', {
      matchId,
      betType,
      scores: `${homeScore}-${awayScore}`,
      winner: winnerTeam,
      totalBets: match.bets.length
    });

    const winningUserIds = winningPlayers.map(bet => bet.userId._id);
    console.log('Winning Player IDs:', winningUserIds);

    // Calculate winning amount for home/away bets
    let winningAmount = match.amount;
    if (winnerTeam !== 'draw') {
      const totalBettors = match.bets.length;
      const winningBettors = winningPlayers.length;
      winningAmount = (match.amount * totalBettors) / winningBettors;
    }

    // Fetch users and update their balances
    const users = await User.find({ _id: { $in: winningUserIds } });
    
    // Update each winning user's balance and create transactions
    for (const user of users) {
      // Update user balance
      user.balance += winningAmount;
      await user.save();
      
      // Find user's bet for this match
      const userBet = match.bets.find(bet => bet.userId._id.toString() === user._id.toString());
      
      // Create transaction record
      const transaction = new Transaction({
        userId: user._id,
        betId: userBet._id,
        amount: winningAmount,
        type: 'credit',
        status: 'completed'
      });
      await transaction.save();

      console.log(`Credited ${winningAmount} to ${user.username}. New balance: ${user.balance}`);
    }

    // Update match as completed
    match.status = 'completed';
    match.winnerTeam = winnerTeam;
    match.scoreHome = homeScore;
    match.scoreAway = awayScore;
    await match.save();

    console.log('Winning Usernames:', users.map(user => user.username));
    console.log('Winning Amount per user:', winningAmount);
    console.log('Match marked as completed');

    res.json({
      success: true,
      match,
      message: 'Match scores updated successfully',
      winningPlayers
    });

  } catch (error) {
    console.error('Error updating match score:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating match score',
      error: error.message
    });
  }
});


router.put('/update/inplay', async (req, res) => {
  try {
    const { matchId } = req.body;
    
    const updatedMatch = await Match.findByIdAndUpdate(
      matchId,
      { status: 'inplay' },
      { new: true }
    );

    if (!updatedMatch) {
      return res.status(404).json({ message: 'Match not found' });
    }

    res.json(updatedMatch);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

router.put('/updateStatus', async (req, res) => {
    try {
      const { matchId, status } = req.body;
      
      // Add 'inplay' to allowed statuses
      const allowedStatuses = ['active', 'completed', 'cancelled', 'inplay'];
      if (!allowedStatuses.includes(status)) {
        return res.status(400).json({ message: 'Invalid status value' });
      }
      
      const updatedMatch = await Match.findByIdAndUpdate(
        matchId,
        { status },
        { new: true }
      );
  
      if (!updatedMatch) {
        return res.status(404).json({ message: 'Match not found' });
      }
  
      res.json(updatedMatch);
    } catch (error) {
      res.status(500).json({ message: 'Server error', error: error.message });
    }
  });

export default router;